package com.mycompany.symesterproject;

public class warehouseWorker extends worker {

    private int forkliftLicense;
    
    
    //These are the constructor methods:
    protected warehouseWorker(){
        
    }
    protected void newwarehouseWorker(int ID, String First, String Last, String Email, int Phone, String Dob){
        this.First_Name = First;
        this.Last_Name = Last;
        this.Worker_ID = ID;
        this.Email = Email;
        this.Phone = Phone;
        this.DoB = Dob;
    }
    
    //This is the get method for the information in the warehouse worker instances.
    private void enterLicense(int license){
        forkliftLicense = license;
    }
    
    //This method calls the orderComplete method from the order class for the specified order.
    public void fulfillOrder(Order order){
        
        order.orderComplete();
    }
}