package com.mycompany.symesterproject;

public class worker {
    int Worker_ID;
    String First_Name;
    String Last_Name;
    String Email;
    int Phone;
    String DoB;
    
    //These are the constructor methods:
    protected worker(){
        
    }
   
    protected void newWorker(int ID, String First, String Last, String Email, int Phone, String Dob){
        this.First_Name = First;
        this.Last_Name = Last;
        this.Worker_ID = ID;
        this.Email = Email;
        this.Phone = Phone;
        this.DoB = Dob;
    }
    
    //These are the get methods for the information in the worker instances.
    public String getWorkerName(){
        String answer = (First_Name + " " + Last_Name);
        
        return answer;
    }
    
    public String getWorkerEmail(){
        String answer = Email;
        
        return answer;
    }
    
    public int getWorkerPhone() {
        int answer = Phone;
        
        return answer;
    }
}
