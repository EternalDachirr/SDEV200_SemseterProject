package com.mycompany.symesterproject;

public class item {
    private int Item_ID;
    String Item_Name;
    String Description;
    //By default, a warehouse will have 1000 of each item in stock.
    int Available_Quantity = 1000;
    
    //These are the constructor methods:
    protected item(){
        
    }
    
    protected void newItem(int ID, String Name) {
        this.Item_ID = ID;
        this.Item_Name = Name;
    }
        
    //These are the get methods for the information in the item instances.
    public void addDescription(String description) {
        this.Description = description;
    }
    
    public void addQuantity(int total){
        Available_Quantity = Available_Quantity + total;
    }
    
    public void subtractQuantity(int total){
        Available_Quantity = Available_Quantity - total;
    }
    
    public int getQuantity() {
        return Available_Quantity;
    }
}
