package com.mycompany.symesterproject;

import java.time.LocalDate;
public class Order {
    double Order_ID;
    LocalDate Date_Placed;
    String Date_Received;
    LocalDate Date_Fulfilled;
    String Item_Ordered;
    int Item_Quantity;
    
    //These are the constructor methods:
    protected Order(){
        
    }
    
    protected double newOrder(String Item, int Quantity){
        
        this.Date_Placed = LocalDate.now(); 
        this.Item_Ordered = Item;
        this.Item_Quantity = Quantity;
        this.Order_ID = (Item_Quantity + ((int)(Math.random() * 100000)) % 1000);
        
        
        return this.Order_ID;
    }
    
    
    //These are the get methods for the information in the order instances.
    public String getItem(){
    
        return Item_Ordered;
    }
    
    public int getItemQuantity(){
        
        return Item_Quantity;
    }
    
    
    //The orderComplete method adds the Date fulfilled to show when the order was fulfilled.
    public void orderComplete(){
        
        this.Date_Fulfilled = LocalDate.now();
        
    }
}
