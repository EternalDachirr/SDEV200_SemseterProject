package com.mycompany.symesterproject;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * JavaFX App
 * 
 * When an order is submitted, fulfilled, and marked to ship through the "Fulfill Order" screen,
 * a return to the "Place Order" screen will show the "Receive Order" screen.
 * 
 * 
 * 
 */
public class App extends Application {
    private final Button btRetail = new Button("Retail Worker");
    private final Button btWareHouse = new Button("Warehouse Worker");
    private final Button btRetailSubmit = new Button("Submit Changes");
    private final Button btWarehouseSubmit = new Button("Submit");
    private final Button btTryAgain = new Button("Try Again");
    private final Button btOkay = new Button("Okay");
    private final Button btReceiveSubmit = new Button("Submit");
    private final Button btReturn = new Button("Return To Main Screen");
    private final TextField tfRetailQuantity = new TextField();
    private final TextField tfName = new TextField();
    private final TextField tfPhone = new TextField();
    private final ComboBox cbRetailSelect = new ComboBox();
    private final CheckBox cbConfirmation = new CheckBox("Confirm Item Receipt");
    private final CheckBox cbShip = new CheckBox("Ship Item");
    private final CheckBox cbUnavailable = new CheckBox("Mark as Unavailable");
    private final TextArea taDetails = new TextArea();
    /**
     *
     * @param primaryStage
     * @throws java.lang.Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        GridPane gridPane = new GridPane();
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        
        gridPane.add(new Label("Please select your position:"), 0, 0);
        gridPane.add(btWareHouse, 1,1);
        gridPane.add(btRetail, 0, 1);
        
        cbRetailSelect.getItems().addAll(
                 "Bananas"
         );
         cbRetailSelect.getItems().addAll(
                 "Apples"
         );
         cbRetailSelect.getItems().addAll(
                 "Pears"
         );

        //Next, I create the scene and show it.
        Scene scene = new Scene(gridPane, 400, 400);
        primaryStage.setTitle("Semester Project: Main Screen");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        //Here are the controls for the buttons
        btRetail.setOnAction(e -> PlaceOrder(primaryStage));
        btRetailSubmit.setOnAction(e -> submitOrder());
        btWareHouse.setOnAction(e -> FulfillOrder(primaryStage));
        btTryAgain.setOnAction(e -> PlaceOrder(primaryStage));
        btOkay.setOnAction(e -> System.exit(0));
        btReceiveSubmit.setOnAction(e -> System.exit(0));
        btReturn.setOnAction(e -> {
            try {
                start(primaryStage);
            } catch (Exception ex) {
                Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }
    public static void main(String[] args) {
        launch();
    }
    public void PlaceOrder(Stage primaryStage){
            if (cbShip.isSelected()){
                ReceiveOrder(primaryStage);    
            }
            else{
         GridPane gridPane2 = new GridPane();
         Stage secondaryStage = primaryStage;

         //Here I create the second gridpane.
        gridPane2.add(new Label("Worker Name: "), 0, 0);
        gridPane2.add(tfName, 1,0);
        gridPane2.add(new Label("Worker Phone: "),0,2);
        gridPane2.add(tfPhone, 1, 2);
        
        gridPane2.add(new Label("Select Your Item: "), 0, 4);
        gridPane2.add(cbRetailSelect, 1, 4);
        
        gridPane2.add(new Label("How Many Do You Need: "), 0, 6);
        gridPane2.add(tfRetailQuantity, 1,6);
        
        gridPane2.add(btRetailSubmit, 1,8);
        gridPane2.add(btReturn, 1,10);
       
        //Next, I create the scene and show it.
        Scene scene = new Scene(gridPane2, 400, 400);
        secondaryStage.setTitle("Semester Project: Place Order");
        secondaryStage.setScene(scene);
        secondaryStage.show();
         }
    }
    
    public Order submitOrder() {
        String exceptionName = "No worker entered";
        String exceptionItem = "No item selected";
        int exceptionQuantity = 0;
        Order exceptionOrder = new Order();
        exceptionOrder.newOrder(exceptionItem, exceptionQuantity);
        try{
        //Here, I get the information from the entry fields
        String WorkerName = tfName.getText();
        String WorkerPhone = tfPhone.getText();
        String Item = (String) cbRetailSelect.getValue();
        int Quantity = (int) Double.parseDouble(tfRetailQuantity.getText());
        //Using that information, I create a new instance of the order class
        Order newOrder = new Order();
        newOrder.newOrder(Item, Quantity);
        //Lastly, I return the orderID
        
        return newOrder;
        }
        catch (Exception E){
        }
        return exceptionOrder;
       
    };
      
    public void ReceiveOrder(Stage primaryStage){
         GridPane gridPane3 = new GridPane();
         Stage secondaryStage = primaryStage;
         
        //Here I create the third gridpane.
        gridPane3.add(new Label("Worker Name: "), 0, 0);
        gridPane3.add(tfName, 1,0);
        gridPane3.add(new Label("Worker Phone: "),0,1);
        gridPane3.add(tfPhone, 1, 1);
        gridPane3.add(cbConfirmation, 0,2);
        
        gridPane3.add(taDetails, 0, 3);
         
        gridPane3.add(btReceiveSubmit, 0, 4);
        //Next, I create the scene and show it.
        Scene scene = new Scene(gridPane3, 800, 400);
        secondaryStage.setTitle("Semester Project: Receive Order");
        secondaryStage.setScene(scene);
        secondaryStage.show();     
    }
    
    public void FulfillOrder(Stage primaryStage) {
        //These declarations need to be here.
         Order order = submitOrder();
         btWarehouseSubmit.setOnAction(e -> orderFulfilled(primaryStage, order));
         cbUnavailable.setIndeterminate(false);
         
         GridPane gridPane4 = new GridPane();
         Stage secondaryStage = primaryStage;
         //First, I get information from the order class
         String Item = order.Item_Ordered;
         int Quantity = order.Item_Quantity;
         String ID =  Double.toString(order.Order_ID);
        //Here I create the fourth gridpane.
        gridPane4.add(new Label("Worker Name: "), 0, 0);
        gridPane4.add(tfName, 1,0);
        gridPane4.add(new Label("Worker Phone: "),0,1);
        gridPane4.add(tfPhone, 1, 1);
        
        gridPane4.add(taDetails, 0, 2);
        taDetails.setText("Order ID: " + ID + "\n");
        taDetails.appendText(Item + "\n");
        taDetails.appendText("Quantity: " + Quantity + "\n");
        
        gridPane4.add(cbShip, 0, 3);
        gridPane4.add(cbUnavailable, 0, 4);
        
        gridPane4.add(btWarehouseSubmit, 0, 5);
        //Next, I create the scene and show it.
        Scene scene = new Scene(gridPane4, 1000, 400);
        secondaryStage.setTitle("Semester Project: FulfillOrder");
        secondaryStage.setScene(scene);
        secondaryStage.show();
        

    }
    public void orderFulfilled(Stage secondaryStage, Order order){
        order.orderComplete();
        if (cbUnavailable.isSelected()){
            GridPane gridPane5 = new GridPane();
            gridPane5.add(new Label("We are sorry but the order that you submitted \n will not be able to be completed. "
                    + "\n Items in the order were unavailable. \n"
                    + "Click Try Again to enter a new order. \n"
                    + "Click Okay to exit."), 0, 0);
            gridPane5.add(btTryAgain, 0, 1);
            gridPane5.add(btOkay, 3, 1);
            //Next, I create the scene and show it.
            Scene scene = new Scene(gridPane5, 400, 110);
            secondaryStage.setTitle("Semester Project: Order Unavailable");
            secondaryStage.setScene(scene);
            secondaryStage.show();
        } 
        else{
            try {
                start(secondaryStage);
            } catch (Exception ex) {
                Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }   
}