package com.mycompany.symesterproject;

public class retailWorker extends worker {
    private int registerClearanceCode;
    
    //These are the constructor methods:
    protected retailWorker(){
        
    }
    
    protected void newRetailWorker(int ID, String First, String Last, String Email, int Phone, String Dob){
        this.First_Name = First;
        this.Last_Name = Last;
        this.Worker_ID = ID;
        this.Email = Email;
        this.Phone = Phone;
        this.DoB = Dob;
    }
    
    
    //This is the method for the information in the retail worker instances.
    private void enterClearance(int clearanceCode){
        this.registerClearanceCode = clearanceCode;
    }
    
    
    //The placeOrder method creates a new instance of the order class.
    public Double placeOrder(String item, int Quantity){

         Order order = new Order();
        
         Double orderID = order.newOrder(item, Quantity);
        
        return orderID;
    }
}
